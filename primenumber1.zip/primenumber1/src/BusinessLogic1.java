public class BusinessLogic1 {
  public static int add(int a, int b) {
    return a + b;
  }
}